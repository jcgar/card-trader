import { Card } from "@/components/ui/card"

export const AdminCollections = () => {
  return (
    <Card className="p-6">
      <h2 className="text-2xl font-bold mb-4">Gestión de Colecciones</h2>
      {/* Implementación pendiente */}
    </Card>
  )
}

