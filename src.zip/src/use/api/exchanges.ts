import { exchanges as data } from "../data"
export const exchanges = data
// const exchanges = [
//   {
//     id: 1,
//     user: "Maria López",
//     avatar: "https://i.pravatar.cc/150?u=maria",
//     offering: "Mundial 2022 #123",
//     requesting: "Premier League #45",
//     status: "pending",
//   },
//   {
//     id: 2,
//     user: "Juan Pérez",
//     avatar: "https://i.pravatar.cc/150?u=juan",
//     offering: "Pokemon #89",
//     requesting: "Yu-Gi-Oh #12",
//     status: "completed",
//   },
// ];

