export const topAchievers = [
  { id: 1, name: "Carlos Gómez", totalAchievements: 15, rareAchievements: 3 },
  { id: 2, name: "Laura Martínez", totalAchievements: 12, rareAchievements: 2 },
  { id: 3, name: "Javier Ruiz", totalAchievements: 10, rareAchievements: 1 },
]

