export const achievementsRanking = {
  collections: [
    { id: 1, userName: "María García", value: 15 },
    { id: 2, userName: "Carlos Rodríguez", value: 12 },
    { id: 3, userName: "Ana Martínez", value: 10 },
  ],
  exchanges: [
    { id: 1, userName: "Luis Fernández", value: 150 },
    { id: 2, userName: "Elena Sánchez", value: 120 },
    { id: 3, userName: "Javier Ruiz", value: 100 },
  ],
  rareCards: [
    { id: 1, userName: "Ana Martínez", value: 25 },
    { id: 2, userName: "María García", value: 20 },
    { id: 3, userName: "Carlos Rodríguez", value: 18 },
  ],
}

