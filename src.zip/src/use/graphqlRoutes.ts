import { INDEX_TOP_COLLECTIONS_QUERY } from "../graphql/query";

export const graphqlRoutes = {
  featuredCollections: INDEX_TOP_COLLECTIONS_QUERY
}
